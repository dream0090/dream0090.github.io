import React from 'react';
import SvgRouter from './svg-router';

describe('SvgRouter', () => {
    it('Dummy test', () => {
        expect(1 + 1).toBe(2);
    });
});
