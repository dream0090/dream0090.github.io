import React from 'react';
import StationSidePanelFooter from './station-side-panel-footer';

describe('StationSidePanelFooter', () => {
    it('Dummy test', () => {
        expect(1 + 1).toBe(2);
    });
});
