import { vi } from 'vitest';

const mockCallbacks = {
    onClose: vi.fn(),
    onUpdate: vi.fn(),
};

describe('ColourModal', () => {
    // TODO: add unit tests
    it('Dummy test', () => {
        expect(1 + 1).toBe(2);
    });
});
