import { vi } from 'vitest';

const mockCallbacks = {
    onClose: vi.fn(),
    onOpenParam: vi.fn(),
};

// TODO: add unit test
describe('Unit tests for TemplateModal component', () => {
    it('Dummy test', () => {
        expect(1 + 1).toBe(2);
    });
});
