# Style sheets

This directory contains CSS style sheets used for in-line `SVG`. 

- `share_[style].css` - For all canvas

The CSS rules of these style sheets will be append to the exported SVG. 